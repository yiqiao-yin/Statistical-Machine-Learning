## ==================================== ##
# ---- Problem 3 ---- #
## ==================================== ##
library(e1071)
base_loc = ### Your Working Directory ###

digit5 = read.table(paste(base_loc, "train.5.txt", sep=""), header=F, sep=",")
digit6 = read.table(paste(base_loc, "train.6.txt", sep=""), header=F, sep=",")

n1 = dim(digit5)[1]
n2 = dim(digit6)[1]
p =  dim(digit5)[2]

## set training and testing
test_prop = 0.2
index1 = sample(n1, round(test_prop * n1), replace=F)  # index for testing
index2 = sample(n2, round(test_prop * n2), replace=F)

xtest  = rbind(digit5[index1, ], digit6[index2, ])
xtrain = rbind(digit5[-index1, ], digit6[-index2, ])
ytest  = factor(c(rep("5", length(index1)), rep("6", length(index2))))
ytrain = factor(c(rep("5", n1 - length(index1)), rep("6", n2 - length(index2))))

## Q2, Q3: perform linear / RBF - SVM with k = 10 fold CV
# default for tune.svm() is 10-fold CV
tune_svm1 = tune.svm(x = xtrain, y = ytrain,
                     cost = seq(0.001, 0.08, 0.002), kernel="linear")
pdf(width = 7, height = 7, file = paste(base_loc, "3-1.pdf", sep=""))
plot(tune_svm1, main = "tuning on Cost(C) of linear-SVM")
dev.off()

tune_svm2 = tune.svm(x = xtrain, y = ytrain, cost = seq(1, 10, 2),
                      gamma = seq(0.004, 0.04, 0.004), kernel="radial")
pdf(width = 7, height = 7, file = paste(base_loc, "3-2.pdf", sep=""))
plot(tune_svm2, type = "contour", main = "tuning on Cost(C) and Gamma of RBF-SVM")
dev.off()

## Q4: train the best model and compare on test data
bestsvm1 = tune_svm1$best.model
bestsvm2 = tune_svm2$best.model

pred_svm1 = predict(bestsvm1, xtest)
pred_svm2 = predict(bestsvm2, xtest)

err1 = sum(pred_svm1 != ytest) / length(ytest)
err2 = sum(pred_svm2 != ytest) / length(ytest)


